clc

sim('clock_test.slx')

time_utc.Data

ymdhms = time_ymdhms_utc.Data 