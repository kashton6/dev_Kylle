clear all; close all; clc; 

jdut1 = 2453101.82740678;
ttt = 0.0426236319;

sim('DCM_UnitTest')

%DCM =Precess*Nutation*Sidereal;
workspace;