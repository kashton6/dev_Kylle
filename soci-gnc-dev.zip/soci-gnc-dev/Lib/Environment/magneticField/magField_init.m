magField = struct;

magField.sample_time_s = .1;

simParams.magField = magField;
clear magField
