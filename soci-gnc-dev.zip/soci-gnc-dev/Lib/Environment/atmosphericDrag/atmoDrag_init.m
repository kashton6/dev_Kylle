% Atmospheric Drag Library Initialization
%   currently no variables needed
atmoDrag = struct;

clear atmoDrag