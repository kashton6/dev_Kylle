gravityGrad = struct;


simParams.gravityGrad = gravityGrad;
clear gravityGrad