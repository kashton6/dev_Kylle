  if SP_ON == 0
    SP_ON = 1;
    GG_ON = 1;
    ATMO_ON = 1;  
  else
     SP_ON = 0;
     GG_ON = 0;
     ATMO_ON = 0; 
  end